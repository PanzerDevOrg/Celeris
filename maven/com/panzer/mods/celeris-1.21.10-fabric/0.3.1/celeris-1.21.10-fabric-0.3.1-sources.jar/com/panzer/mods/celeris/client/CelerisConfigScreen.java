//? if fabric {
package com.panzer.mods.celeris.client;

import com.panzer.mods.celeris.config.CelerisFabricConfig;
import com.panzer.mods.celeris.config.CelerisSettings;
import net.minecraft.class_2561;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_7842;
import net.minecraft.class_7919;

/**
 * Celeris's settings on Fabric, opened from Mod Menu ({@code CelerisModMenu}).
 * Built from vanilla widgets only; the value is saved when the screen closes.
 * NeoForge uses its own generated screen for {@code CelerisConfig} instead.
 */
public final class CelerisConfigScreen extends class_437 {

    private static final int WIDTH = 200;
    private static final int RANGE = CelerisSettings.MAX_COMPRESSION_LEVEL - CelerisSettings.MIN_COMPRESSION_LEVEL;

    private final class_437 parent;
    private int level = CelerisSettings.compressionLevel();

    public CelerisConfigScreen(class_437 parent) {
        super(class_2561.method_43471("celeris.configuration.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int x = this.field_22789 / 2 - WIDTH / 2;
        int y = this.field_22790 / 2 - 30;
        method_37063(new class_7842(x, y - 24, WIDTH, 9, this.field_22785, this.field_22793));
        LevelSlider slider = new LevelSlider(x, y, WIDTH, 20);
        slider.method_47400(class_7919.method_47407(class_2561.method_43471("celeris.configuration.compressionLevel.tooltip")));
        method_37063(slider);
        method_37063(class_4185.method_46430(class_5244.field_24334, button -> method_25419())
                .method_46434(x, y + 28, WIDTH, 20)
                .method_46431());
    }

    @Override
    public void method_25419() {
        CelerisFabricConfig.setCompressionLevel(this.level);
        if (this.field_22787 != null) {
            this.field_22787.method_1507(this.parent);
        }
    }

    private static class_2561 levelLabel(int level) {
        class_2561 value = level == 0
                ? class_2561.method_43471("celeris.configuration.compressionLevel.off")
                : class_2561.method_43470(Integer.toString(level));
        return class_2561.method_43469("celeris.configuration.compressionLevel.value",
                class_2561.method_43471("celeris.configuration.compressionLevel"), value);
    }

    private final class LevelSlider extends class_357 {

        LevelSlider(int x, int y, int width, int height) {
            super(x, y, width, height, levelLabel(level),
                    (double) (level - CelerisSettings.MIN_COMPRESSION_LEVEL) / RANGE);
        }

        @Override
        protected void method_25346() {
            method_25355(levelLabel(level));
        }

        @Override
        protected void method_25344() {
            level = CelerisSettings.MIN_COMPRESSION_LEVEL + (int) Math.round(this.field_22753 * RANGE);
        }
    }
}
//?}
