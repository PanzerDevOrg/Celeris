package com.panzer.mods.celeris.network;

import com.panzer.mods.celeris.Celeris;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import org.jetbrains.annotations.NotNull;

/**
 * A {@link class_8710} carrying a Celeris-compressed byte blob --
 * the wire format {@link PayloadCompression} and {@link NetworkRegistry}
 * send/receive. You won't normally construct this directly; get one from
 * {@link PayloadCompression#compress}.
 *
 * <p>This rides on top of NeoForge's standard payload API rather than
 * touching Netty directly, and is an optional, additive layer on top of
 * Vanilla's own transport-level compression -- worth it for large,
 * already-structured payloads (bulk world data, big inventory syncs, SIMD
 * results) where zstd beats zlib's ratio/speed tradeoff. See README.md,
 * "Module 1.3 redesign", for the full design reasoning.
 */
public record CompressedPayload(byte[] data, boolean compressed,
                                int originalSize) implements class_8710 {

    //? >1.21.10 {
    /*public static final Type<CompressedPayload> TYPE =
            new Type<>(Identifier.fromNamespaceAndPath(Celeris.MOD_ID, "compressed_blob"));
    *///?} else {
    public static final class_9154<CompressedPayload> TYPE =
            new class_9154<>(class_2960.method_60655(Celeris.MOD_ID, "compressed_blob"));
    //?}

    /** Hard cap on wire size for this payload type -- {@link PayloadCompression#compress} results larger than this will fail to encode. */
    public static final int MAX_COMPRESSED_PAYLOAD_SIZE = 1024 * 1024;

    public static final class_9139<class_9129, CompressedPayload> STREAM_CODEC =
            class_9139.method_56436(
                    class_9135.method_56895(MAX_COMPRESSED_PAYLOAD_SIZE), CompressedPayload::data,
                    class_9135.field_48547, CompressedPayload::compressed,
                    class_9135.field_48550, CompressedPayload::originalSize,
                    CompressedPayload::new
            );

    @Override
    public @NotNull class_9154<CompressedPayload> method_56479() {
        return TYPE;
    }
}
